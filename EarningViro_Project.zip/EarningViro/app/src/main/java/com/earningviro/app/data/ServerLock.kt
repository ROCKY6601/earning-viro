package com.earningviro.app.data

import android.content.Context

/**
 * Har server ka "last click" time SharedPreferences me save karta hai.
 * Isi device par har server sirf 24 ghante me EK baar click ho sakta hai.
 */
object ServerLock {
    private const val PREFS = "earning_viro_prefs"
    private const val LOCK_MS = 24L * 60 * 60 * 1000 // 24 ghante

    /** Isse pata chalta hai ki us server ka "just closed" animation abhi bhi dikhana hai (pehle 20 second) */
    const val ANIM_WINDOW_MS = 20_000L

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun markClicked(context: Context, serverId: Int) {
        prefs(context).edit()
            .putLong("last_click_$serverId", System.currentTimeMillis())
            .apply()
    }

    private fun lastClickTime(context: Context, serverId: Int): Long =
        prefs(context).getLong("last_click_$serverId", 0L)

    /** 0 ka matlab: locked nahi hai, click kar sakte ho. */
    fun remainingLockMillis(context: Context, serverId: Int): Long {
        val last = lastClickTime(context, serverId)
        if (last == 0L) return 0L
        val elapsed = System.currentTimeMillis() - last
        return (LOCK_MS - elapsed).coerceAtLeast(0L)
    }

    /** Click hue abhi kitni der hui — animation window check karne ke liye. */
    fun elapsedSinceClick(context: Context, serverId: Int): Long {
        val last = lastClickTime(context, serverId)
        if (last == 0L) return Long.MAX_VALUE
        return System.currentTimeMillis() - last
    }

    fun formatRemaining(ms: Long): String {
        val totalMinutes = (ms / 60_000L).coerceAtLeast(0L)
        val hours = totalMinutes / 60
        val minutes = totalMinutes % 60
        return if (hours > 0) "${hours}h ${minutes}m" else "${minutes}m"
    }
}
