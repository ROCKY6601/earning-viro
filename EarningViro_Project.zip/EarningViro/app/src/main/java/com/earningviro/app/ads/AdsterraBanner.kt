package com.earningviro.app.ads

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color as AndroidColor
import android.net.Uri
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView

/**
 * Adsterra ke Banner ad ka HTML/JS code. Adsterra Dashboard > Ad Units > Banner se liya gaya hai.
 * Agar kabhi naya code milta hai to bas neeche wale 2 constants update kar dena.
 */
private const val ADSTERRA_KEY = "954917a1385db42b4596e8648e8e460c"
private const val ADSTERRA_SCRIPT_URL =
    "https://www.highrevenueformat.com/954917a1385db42b4596e8648e8e460c/invoke.js"

private fun adsterraHtml(): String = """
    <html>
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
          html, body {
            margin: 0; padding: 0; background: transparent;
            display: flex; align-items: center; justify-content: center;
            overflow: hidden;
          }
        </style>
      </head>
      <body>
        <script type="text/javascript">
          atOptions = {
            'key' : '$ADSTERRA_KEY',
            'format' : 'iframe',
            'height' : 50,
            'width' : 320,
            'params' : {}
          };
        </script>
        <script type="text/javascript" src="$ADSTERRA_SCRIPT_URL"></script>
      </body>
    </html>
""".trimIndent()

/**
 * Adsterra 320x50 banner ad. Jitni baar isko call karoge utni jagah alag banner load hoga.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun AdsterraBannerAd() {
    val context = LocalContext.current
    var webViewRef by remember { mutableStateOf<WebView?>(null) }

    Box(
        Modifier
            .width(320.dp)
            .height(50.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(Color.White.copy(alpha = 0.04f)),
        contentAlignment = Alignment.Center
    ) {
        AndroidView(
            factory = { ctx ->
                WebView(ctx).apply {
                    settings.javaScriptEnabled = true
                    settings.loadWithOverviewMode = true
                    settings.useWideViewPort = true
                    setBackgroundColor(AndroidColor.TRANSPARENT)
                    webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(
                            view: WebView?,
                            url: String?
                        ): Boolean {
                            // Ad par click hone par external browser me kholo
                            return if (url != null) {
                                try {
                                    context.startActivity(
                                        Intent(Intent.ACTION_VIEW, Uri.parse(url))
                                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    )
                                    true
                                } catch (e: Exception) {
                                    false
                                }
                            } else false
                        }
                    }
                    loadDataWithBaseURL(
                        "https://www.highrevenueformat.com",
                        adsterraHtml(),
                        "text/html",
                        "UTF-8",
                        null
                    )
                    webViewRef = this
                }
            },
            modifier = Modifier.width(320.dp).height(50.dp)
        )
    }

    DisposableEffect(Unit) {
        onDispose {
            webViewRef?.apply {
                stopLoading()
                destroy()
            }
        }
    }
}
