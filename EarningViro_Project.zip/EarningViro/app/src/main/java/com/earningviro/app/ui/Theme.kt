package com.earningviro.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object Palette {
    val Bg0 = Color(0xFF07070F)
    val Bg1 = Color(0xFF110C2B)
    val Violet = Color(0xFF7C4DFF)
    val Cyan = Color(0xFF00E5FF)
    val Pink = Color(0xFFFF4D8D)
    val Gold = Color(0xFFFFC857)
    val Green = Color(0xFF2EE59D)
    val TextPrimary = Color(0xFFF5F5FF)
    val TextSecondary = Color(0xFF9A9AB8)
}

@Composable
fun EarningViroTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Palette.Violet,
            background = Palette.Bg0,
            surface = Palette.Bg1,
            onBackground = Palette.TextPrimary,
            onSurface = Palette.TextPrimary
        ),
        content = content
    )
}
