package com.earningviro.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.runtime.*
import com.earningviro.app.ads.UnityAdsManager
import com.earningviro.app.ui.EarningViroTheme
import com.earningviro.app.ui.HomeScreen
import com.earningviro.app.ui.SplashScreen
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Unity Ads SDK start
        UnityAdsManager.initialize(applicationContext)

        setContent {
            EarningViroTheme {
                var showSplash by remember { mutableStateOf(true) }
                LaunchedEffect(Unit) { delay(2200); showSplash = false }

                Crossfade(showSplash, animationSpec = tween(700), label = "root") { splash ->
                    if (splash) SplashScreen() else HomeScreen(this@MainActivity)
                }
            }
        }
    }
}
