package com.earningviro.app.data

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.Public
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

data class ServerItem(
    val id: Int,
    val name: String,
    val subtitle: String,
    val url: String,
    val tag: String,
    val icon: ImageVector,
    val colors: List<Color>,
    val features: List<String>
)

object Servers {
    // 👇 Yahan apne 3 server ke asli links daalo
    val list = listOf(
        ServerItem(
            id = 1,
            name = "Server 1",
            subtitle = "Fast • Stable • Recommended",
            url = "https://direct-link.net/9455776/kxbhodvshYdj",
            tag = "BEST",
            icon = Icons.Rounded.Bolt,
            colors = listOf(Color(0xFF7C4DFF), Color(0xFF00B0FF)),
            features = listOf("High Speed", "Stable")
        ),
        ServerItem(
            id = 2,
            name = "Server 2",
            subtitle = "Smooth • Reliable • Secure",
            url = "https://link-center.net/9547191/doicMDWEsupY",
            tag = "POPULAR",
            icon = Icons.Rounded.Cloud,
            colors = listOf(Color(0xFFFF4D8D), Color(0xFFFF8A47)),
            features = listOf("Reliable", "Secure")
        ),
        ServerItem(
            id = 3,
            name = "Server 3",
            subtitle = "Backup • Always Online",
            url = "https://link-hub.net/9549040/UIEg1TcELEkF",
            tag = "BACKUP",
            icon = Icons.Rounded.Public,
            colors = listOf(Color(0xFF00E5A8), Color(0xFF00B8D4)),
            features = listOf("Backup", "24/7")
        )
    )
}
