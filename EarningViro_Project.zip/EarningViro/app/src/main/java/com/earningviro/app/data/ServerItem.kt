package com.earningviro.app.data

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.RocketLaunch
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

data class ServerItem(
    val id: Int,
    val name: String,
    val subtitle: String,
    val url: String,
    val tag: String,
    val icon: ImageVector,
    val colors: List<Color>,
    val features: List<String>
)

object Servers {
    // 👇 Server 4 se 10 tak ke links abhi placeholder hain — ye link jaise bhejo waise daal dena
    val list = listOf(
        ServerItem(
            id = 1,
            name = "Server 1",
            subtitle = "Fast • Stable • Recommended",
            url = "https://direct-link.net/9455776/kxbhodvshYdj",
            tag = "BEST",
            icon = Icons.Rounded.Bolt,
            colors = listOf(Color(0xFF7C4DFF), Color(0xFF00B0FF)),
            features = listOf("High Speed", "Stable")
        ),
        ServerItem(
            id = 2,
            name = "Server 2",
            subtitle = "Smooth • Reliable • Secure",
            url = "https://link-center.net/9547191/doicMDWEsupY",
            tag = "POPULAR",
            icon = Icons.Rounded.Cloud,
            colors = listOf(Color(0xFFFF4D8D), Color(0xFFFF8A47)),
            features = listOf("Reliable", "Secure")
        ),
        ServerItem(
            id = 3,
            name = "Server 3",
            subtitle = "Backup • Always Online",
            url = "https://link-hub.net/9549040/UIEg1TcELEkF",
            tag = "BACKUP",
            icon = Icons.Rounded.Public,
            colors = listOf(Color(0xFF00E5A8), Color(0xFF00B8D4)),
            features = listOf("Backup", "24/7")
        ),
        ServerItem(
            id = 4,
            name = "Server 4",
            subtitle = "Secure • Encrypted • Safe",
            url = "https://link-center.net/9455776/XVNcNv9yonKb",
            tag = "SECURE",
            icon = Icons.Rounded.Shield,
            colors = listOf(Color(0xFF00C6FF), Color(0xFF0072FF)),
            features = listOf("Encrypted", "Safe")
        ),
        ServerItem(
            id = 5,
            name = "Server 5",
            subtitle = "Ultra Fast • Low Ping",
            url = "https://link-hub.net/9455776/XeiZdQ10HA7n",
            tag = "FAST",
            icon = Icons.Rounded.RocketLaunch,
            colors = listOf(Color(0xFFFF6A00), Color(0xFFFFC837)),
            features = listOf("Low Ping", "Fast")
        ),
        ServerItem(
            id = 6,
            name = "Server 6",
            subtitle = "Premium • High Quality",
            url = "https://link-center.net/9455776/TTPkyBqNKTWM",
            tag = "PREMIUM",
            icon = Icons.Rounded.Star,
            colors = listOf(Color(0xFFFFC857), Color(0xFFFF9F43)),
            features = listOf("Premium", "HD")
        ),
        ServerItem(
            id = 7,
            name = "Server 7",
            subtitle = "Safe • Protected Access",
            url = "https://link-hub.net/9455776/5yWxxbylGxwF",
            tag = "SAFE",
            icon = Icons.Rounded.Security,
            colors = listOf(Color(0xFF2EE59D), Color(0xFF00B8D4)),
            features = listOf("Protected", "Safe")
        ),
        ServerItem(
            id = 8,
            name = "Server 8",
            subtitle = "Quick Access • No Delay",
            url = "https://direct-link.net/9455776/ShKPsFloAbHM",
            tag = "QUICK",
            icon = Icons.Rounded.Speed,
            colors = listOf(Color(0xFF7C4DFF), Color(0xFFFF4D8D)),
            features = listOf("Quick", "No Delay")
        ),
        ServerItem(
            id = 9,
            name = "Server 9",
            subtitle = "Global • Multi Region",
            url = "https://link-target.net/9455776/OxNxU4u3pYgN",
            tag = "GLOBAL",
            icon = Icons.Rounded.Language,
            colors = listOf(Color(0xFF00E5FF), Color(0xFF7C4DFF)),
            features = listOf("Global", "Multi Region")
        ),
        ServerItem(
            id = 10,
            name = "Server 10",
            subtitle = "Reliable • Always Ready",
            url = "https://direct-link.net/9455776/bteET67Jte2Z",
            tag = "RELIABLE",
            icon = Icons.Rounded.Storage,
            colors = listOf(Color(0xFFFF8A47), Color(0xFFFF4D8D)),
            features = listOf("Reliable", "Ready")
        )
    )
}
