package com.earningviro.app.ui

import android.app.Activity
import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.WorkspacePremium
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.earningviro.app.ads.AdResult
import com.earningviro.app.ads.UnityAdsManager
import com.earningviro.app.data.ServerItem
import com.earningviro.app.data.Servers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(activity: Activity) {
    val context = LocalContext.current
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }

    fun toast(msg: String) { scope.launch { snackbar.showSnackbar(msg) } }

    fun openServer(s: ServerItem) {
        try {
            context.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse(s.url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            toast("Link open nahi ho paya")
        }
    }

    fun onServerClick(s: ServerItem) {
        if (busy) return
        busy = true
        UnityAdsManager.showRewarded(activity) { result, message ->
            busy = false
            when (result) {
                AdResult.REWARDED -> { toast("✅ Reward mil gaya! ${s.name} khul raha hai…"); openServer(s) }
                AdResult.SKIPPED -> toast("Server unlock karne ke liye ad poora dekhna zaroori hai")
                AdResult.FAILED -> toast(message ?: "Kuch gadbad hui, dobara try karo")
            }
        }
    }

    Box(Modifier.fillMaxSize()) {
        AnimatedBackground()

        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 16.dp)
        ) {
            Header(adReady = UnityAdsManager.isAdLoaded)
            Spacer(Modifier.height(28.dp))
            Text("Choose your server", color = Palette.TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(
                "Server par tap karo → ek short ad dekho → server turant khul jayega.",
                color = Palette.TextSecondary, fontSize = 13.sp, lineHeight = 19.sp
            )
            Spacer(Modifier.height(20.dp))

            Servers.list.forEachIndexed { index, item ->
                ServerCard(item, index, enabled = !busy) { onServerClick(item) }
                Spacer(Modifier.height(16.dp))
            }

            Spacer(Modifier.height(8.dp))
            Text(
                "Powered by Unity Ads • © Earning Viro",
                color = Palette.TextSecondary.copy(alpha = 0.6f),
                fontSize = 11.sp, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }

        // Loading overlay (jab tak ad load ho raha ho)
        AnimatedVisibility(busy, enter = fadeIn(), exit = fadeOut()) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.65f))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {},
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = Palette.Cyan, strokeWidth = 3.dp)
                    Spacer(Modifier.height(16.dp))
                    Text("Ad load ho raha hai…", color = Palette.TextPrimary, fontSize = 14.sp)
                }
            }
        }

        SnackbarHost(
            snackbar,
            Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(16.dp)
        )
    }
}

/* ---------- Background ---------- */

private fun DrawScope.glow(color: Color, center: Offset, radius: Float) {
    drawCircle(
        brush = Brush.radialGradient(listOf(color, Color.Transparent), center = center, radius = radius),
        radius = radius, center = center
    )
}

@Composable
private fun AnimatedBackground() {
    val t = rememberInfiniteTransition(label = "bg")
    val a by t.animateFloat(0f, 1f, infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Reverse), label = "a")
    val b by t.animateFloat(0f, 1f, infiniteRepeatable(tween(12000, easing = LinearEasing), RepeatMode.Reverse), label = "b")
    Canvas(Modifier.fillMaxSize()) {
        drawRect(Brush.verticalGradient(listOf(Palette.Bg1, Palette.Bg0)))
        glow(Palette.Violet.copy(alpha = 0.35f), Offset(size.width * (0.1f + 0.6f * a), size.height * (0.10f + 0.10f * b)), size.width * 0.8f)
        glow(Palette.Pink.copy(alpha = 0.22f), Offset(size.width * (0.9f - 0.6f * b), size.height * (0.55f + 0.15f * a)), size.width * 0.75f)
        glow(Palette.Cyan.copy(alpha = 0.18f), Offset(size.width * (0.2f + 0.5f * b), size.height * (0.95f - 0.1f * a)), size.width * 0.7f)
    }
}

/* ---------- Header ---------- */

@Composable
private fun Header(adReady: Boolean) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("Welcome 👋", color = Palette.TextSecondary, fontSize = 13.sp)
                Text(
                    "EARNING VIRO",
                    style = TextStyle(
                        brush = Brush.linearGradient(listOf(Palette.Cyan, Palette.Violet, Palette.Pink)),
                        fontSize = 28.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp
                    )
                )
            }
            PremiumBadge()
        }
        Spacer(Modifier.height(14.dp))
        AdStatusPill(adReady)
    }
}

@Composable
private fun PremiumBadge() {
    Row(
        Modifier
            .clip(CircleShape)
            .background(Brush.horizontalGradient(listOf(Palette.Gold, Color(0xFFFF9F43))))
            .padding(horizontal = 12.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Rounded.WorkspacePremium, null, tint = Color(0xFF3A2500), modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(4.dp))
        Text("PREMIUM", color = Color(0xFF3A2500), fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
    }
}

@Composable
private fun AdStatusPill(ready: Boolean) {
    val t = rememberInfiniteTransition(label = "dot")
    val pulse by t.animateFloat(0.35f, 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "p")
    val c = if (ready) Palette.Green else Palette.Gold
    Row(
        Modifier
            .clip(CircleShape)
            .background(c.copy(alpha = 0.12f))
            .border(1.dp, c.copy(alpha = 0.35f), CircleShape)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(8.dp).alpha(pulse).clip(CircleShape).background(c))
        Spacer(Modifier.width(8.dp))
        Text(if (ready) "Ads ready" else "Ads loading…", color = c, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

/* ---------- Server card ---------- */

@Composable
private fun ServerCard(item: ServerItem, index: Int, enabled: Boolean, onClick: () -> Unit) {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(200L + 170L * index); visible = true }

    AnimatedVisibility(
        visible,
        enter = fadeIn(tween(500)) + slideInVertically(tween(650, easing = FastOutSlowInEasing)) { it / 3 }
    ) {
        val shape = RoundedCornerShape(26.dp)
        Column(
            Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(Brush.linearGradient(listOf(Color.White.copy(alpha = 0.10f), Color.White.copy(alpha = 0.03f))))
                .border(1.dp, Brush.linearGradient(item.colors.map { it.copy(alpha = 0.7f) }), shape)
                .padding(20.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(54.dp)
                        .shadow(12.dp, RoundedCornerShape(18.dp), ambientColor = item.colors.first(), spotColor = item.colors.first())
                        .clip(RoundedCornerShape(18.dp))
                        .background(Brush.linearGradient(item.colors)),
                    contentAlignment = Alignment.Center
                ) { Icon(item.icon, null, tint = Color.White, modifier = Modifier.size(30.dp)) }

                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(item.name, color = Palette.TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text(item.subtitle, color = Palette.TextSecondary, fontSize = 12.sp)
                }
                Text(
                    item.tag,
                    color = item.colors.first(), fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp,
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(item.colors.first().copy(alpha = 0.15f))
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                )
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item.features.forEach { f ->
                    Text(
                        "● $f", color = Palette.TextSecondary, fontSize = 11.sp,
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.06f))
                            .padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
            }
            Spacer(Modifier.height(18.dp))
            PremiumButton("Watch Ad & Open", item.colors, enabled, onClick)
        }
    }
}

@Composable
private fun PremiumButton(text: String, colors: List<Color>, enabled: Boolean, onClick: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        if (pressed) 0.95f else 1f, spring(Spring.DampingRatioMediumBouncy), label = "press"
    )
    val t = rememberInfiniteTransition(label = "shine")
    val shine by t.animateFloat(-0.5f, 1.5f, infiniteRepeatable(tween(2400, easing = LinearEasing)), label = "sh")
    val shape = RoundedCornerShape(16.dp)

    Box(
        Modifier
            .fillMaxWidth()
            .height(54.dp)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .shadow(14.dp, shape, ambientColor = colors.first(), spotColor = colors.first())
            .clip(shape)
            .background(Brush.horizontalGradient(colors))
            .drawWithContent {
                drawContent()
                val band = size.width * 0.3f
                val x = shine * size.width
                drawRect(
                    Brush.linearGradient(
                        listOf(Color.Transparent, Color.White.copy(alpha = 0.35f), Color.Transparent),
                        start = Offset(x - band, 0f), end = Offset(x, size.height)
                    )
                )
            }
            .clickable(interactionSource = interaction, indication = null, enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.PlayCircle, null, tint = Color.White, modifier = Modifier.size(24.dp))
            Spacer(Modifier.width(8.dp))
            Text(text, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
        }
    }
}
