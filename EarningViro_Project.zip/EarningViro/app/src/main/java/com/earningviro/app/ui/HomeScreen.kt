package com.earningviro.app.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.ContentTransform
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.WorkspacePremium
import androidx.compose.material3.Icon
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.earningviro.app.data.ServerItem
import com.earningviro.app.data.ServerLock
import com.earningviro.app.data.Servers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(activity: Activity) {
    val context = LocalContext.current
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    // Har second update hota hai taaki lock/countdown live dikhe, bina app restart kiye
    var tick by remember { mutableStateOf(0L) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            tick = System.currentTimeMillis()
        }
    }

    var selectedSlot by remember { mutableStateOf(1) }
    val currentServers = if (selectedSlot == 1) Servers.slot1 else Servers.slot2

    fun toast(msg: String) { scope.launch { snackbar.showSnackbar(msg) } }

    fun openServer(s: ServerItem) {
        try {
            context.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse(s.url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            toast("Link open nahi ho paya")
        }
    }

    Box(Modifier.fillMaxSize()) {
        AnimatedBackground()

        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 16.dp)
        ) {
            Header()
            Spacer(Modifier.height(24.dp))
            SlotSwitcher(selectedSlot = selectedSlot, onSelect = { selectedSlot = it })
            Spacer(Modifier.height(20.dp))
            Text("Choose your server", color = Palette.TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(
                "Server par tap karo → server turant khul jayega. Har server 24 ghante me sirf ek baar khulega.",
                color = Palette.TextSecondary, fontSize = 13.sp, lineHeight = 19.sp
            )
            Spacer(Modifier.height(20.dp))

            currentServers.forEachIndexed { index, item ->
                key(item.id) {
                    ServerCard(
                        item = item,
                        index = index,
                        tick = tick,
                        onOpen = {
                            openServer(item)
                            ServerLock.markClicked(context, item.id)
                        }
                    )
                    Spacer(Modifier.height(16.dp))
                }
            }

            Spacer(Modifier.height(8.dp))
            Text(
                "© Earning Viro",
                color = Palette.TextSecondary.copy(alpha = 0.6f),
                fontSize = 11.sp, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }

        SnackbarHost(
            snackbar,
            Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(16.dp)
        )
    }
}

/* ---------- Background ---------- */

private fun DrawScope.glow(color: Color, center: Offset, radius: Float) {
    drawCircle(
        brush = Brush.radialGradient(listOf(color, Color.Transparent), center = center, radius = radius),
        radius = radius, center = center
    )
}

@Composable
private fun AnimatedBackground() {
    val t = rememberInfiniteTransition(label = "bg")
    val a by t.animateFloat(0f, 1f, infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Reverse), label = "a")
    val b by t.animateFloat(0f, 1f, infiniteRepeatable(tween(12000, easing = LinearEasing), RepeatMode.Reverse), label = "b")
    Canvas(Modifier.fillMaxSize()) {
        drawRect(Brush.verticalGradient(listOf(Palette.Bg1, Palette.Bg0)))
        glow(Palette.Violet.copy(alpha = 0.35f), Offset(size.width * (0.1f + 0.6f * a), size.height * (0.10f + 0.10f * b)), size.width * 0.8f)
        glow(Palette.Pink.copy(alpha = 0.22f), Offset(size.width * (0.9f - 0.6f * b), size.height * (0.55f + 0.15f * a)), size.width * 0.75f)
        glow(Palette.Cyan.copy(alpha = 0.18f), Offset(size.width * (0.2f + 0.5f * b), size.height * (0.95f - 0.1f * a)), size.width * 0.7f)
    }
}

/* ---------- Header ---------- */

@Composable
private fun Header() {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Column {
            Text("Welcome 👋", color = Palette.TextSecondary, fontSize = 13.sp)
            Text(
                "EARNING VIRO",
                style = TextStyle(
                    brush = Brush.linearGradient(listOf(Palette.Cyan, Palette.Violet, Palette.Pink)),
                    fontSize = 28.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp
                )
            )
        }
        PremiumBadge()
    }
}

@Composable
private fun PremiumBadge() {
    Row(
        Modifier
            .clip(CircleShape)
            .background(Brush.horizontalGradient(listOf(Palette.Gold, Color(0xFFFF9F43))))
            .padding(horizontal = 12.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Rounded.WorkspacePremium, null, tint = Color(0xFF3A2500), modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(4.dp))
        Text("PREMIUM", color = Color(0xFF3A2500), fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
    }
}

/* ---------- Slot switcher ---------- */

@Composable
private fun SlotSwitcher(selectedSlot: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(Color.White.copy(alpha = 0.05f))
            .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(18.dp))
            .padding(6.dp)
    ) {
        SlotTab("Slot 1", selectedSlot == 1, Modifier.weight(1f)) { onSelect(1) }
        Spacer(Modifier.width(6.dp))
        SlotTab("Slot 2", selectedSlot == 2, Modifier.weight(1f)) { onSelect(2) }
    }
}

@Composable
private fun SlotTab(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Box(
        modifier
            .clip(shape)
            .background(
                if (selected) Brush.horizontalGradient(listOf(Palette.Violet, Palette.Cyan))
                else Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent))
            )
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            color = if (selected) Color.White else Palette.TextSecondary,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

/* ---------- Server card ---------- */

@Composable
private fun ServerCard(item: ServerItem, index: Int, tick: Long, onOpen: () -> Unit) {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(120L + 90L * index); visible = true }

    val context = LocalContext.current
    // localClicked turant UI update ke liye — persisted lock ka agla tick aane tak wait nahi karna
    var localClicked by remember { mutableStateOf(false) }

    val remaining = remember(tick, localClicked) { ServerLock.remainingLockMillis(context, item.id) }
    val elapsed = remember(tick, localClicked) { ServerLock.elapsedSinceClick(context, item.id) }
    val isLocked = localClicked || remaining > 0
    val justClosed = localClicked || elapsed < ServerLock.ANIM_WINDOW_MS

    AnimatedVisibility(
        visible,
        enter = fadeIn(tween(500)) + slideInVertically(tween(650, easing = FastOutSlowInEasing)) { it / 3 }
    ) {
        val shape = RoundedCornerShape(26.dp)
        Column(
            Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(Brush.linearGradient(listOf(Color.White.copy(alpha = 0.10f), Color.White.copy(alpha = 0.03f))))
                .border(1.dp, Brush.linearGradient(item.colors.map { it.copy(alpha = 0.7f) }), shape)
                .padding(20.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(54.dp)
                        .shadow(12.dp, RoundedCornerShape(18.dp), ambientColor = item.colors.first(), spotColor = item.colors.first())
                        .clip(RoundedCornerShape(18.dp))
                        .background(Brush.linearGradient(item.colors)),
                    contentAlignment = Alignment.Center
                ) { Icon(item.icon, null, tint = Color.White, modifier = Modifier.size(30.dp)) }

                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(item.name, color = Palette.TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text(item.subtitle, color = Palette.TextSecondary, fontSize = 12.sp)
                }
                Text(
                    item.tag,
                    color = item.colors.first(), fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp,
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(item.colors.first().copy(alpha = 0.15f))
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                )
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item.features.forEach { f ->
                    Text(
                        "● $f", color = Palette.TextSecondary, fontSize = 11.sp,
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.06f))
                            .padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
            }
            Spacer(Modifier.height(18.dp))
            ServerActionButton(
                colors = item.colors,
                isLocked = isLocked,
                justClosed = justClosed,
                remainingLabel = if (isLocked) ServerLock.formatRemaining(remaining.coerceAtLeast(1)) else null,
                onClick = {
                    localClicked = true
                    onOpen()
                }
            )
        }
    }
}

@Composable
private fun ServerActionButton(
    colors: List<Color>,
    isLocked: Boolean,
    justClosed: Boolean,
    remainingLabel: String?,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(16.dp)

    Column {
        AnimatedContent(
            targetState = isLocked,
            transitionSpec = {
                (fadeIn(tween(350)) + scaleIn(tween(350), initialScale = 0.85f)) togetherWith
                    (fadeOut(tween(200)) + scaleOut(tween(200), targetScale = 0.9f))
            },
            label = "server_button"
        ) { locked ->
            if (!locked) {
                OpenButton(colors = colors, onClick = onClick)
            } else {
                ClosedButton(pulsing = justClosed)
            }
        }
        if (isLocked && remainingLabel != null) {
            Spacer(Modifier.height(6.dp))
            Text(
                "Available in $remainingLabel",
                color = Palette.TextSecondary,
                fontSize = 11.sp,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun OpenButton(colors: List<Color>, onClick: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        if (pressed) 0.95f else 1f, spring(Spring.DampingRatioMediumBouncy), label = "press"
    )
    val t = rememberInfiniteTransition(label = "shine")
    val shine by t.animateFloat(-0.5f, 1.5f, infiniteRepeatable(tween(2400, easing = LinearEasing)), label = "sh")
    val shape = RoundedCornerShape(16.dp)

    Box(
        Modifier
            .fillMaxWidth()
            .height(54.dp)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .shadow(14.dp, shape, ambientColor = colors.first(), spotColor = colors.first())
            .clip(shape)
            .background(Brush.horizontalGradient(colors))
            .drawWithContent {
                drawContent()
                val band = size.width * 0.3f
                val x = shine * size.width
                drawRect(
                    Brush.linearGradient(
                        listOf(Color.Transparent, Color.White.copy(alpha = 0.35f), Color.Transparent),
                        start = Offset(x - band, 0f), end = Offset(x, size.height)
                    )
                )
            }
            .clickable(interactionSource = interaction, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.OpenInNew, null, tint = Color.White, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(8.dp))
            Text("Open Server", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
        }
    }
}

@Composable
private fun ClosedButton(pulsing: Boolean) {
    val shape = RoundedCornerShape(16.dp)
    val t = rememberInfiniteTransition(label = "closed_pulse")
    val pulseAlpha by t.animateFloat(
        initialValue = if (pulsing) 0.55f else 1f,
        targetValue = if (pulsing) 1f else 1f,
        animationSpec = infiniteRepeatable(tween(700, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pa"
    )
    val pulseScale by t.animateFloat(
        initialValue = if (pulsing) 0.97f else 1f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(700, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "ps"
    )

    Box(
        Modifier
            .fillMaxWidth()
            .height(54.dp)
            .graphicsLayer {
                alpha = if (pulsing) pulseAlpha else 0.55f
                scaleX = if (pulsing) pulseScale else 1f
                scaleY = if (pulsing) pulseScale else 1f
            }
            .clip(shape)
            .background(Color.White.copy(alpha = 0.06f))
            .border(1.dp, Color.White.copy(alpha = 0.15f), shape)
            .clickable(enabled = false) {},
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Close, null, tint = Palette.TextSecondary, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
            Text("Close", color = Palette.TextSecondary, fontSize = 15.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
        }
    }
}
