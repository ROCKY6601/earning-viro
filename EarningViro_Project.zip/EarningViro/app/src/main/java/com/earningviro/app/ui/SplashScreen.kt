package com.earningviro.app.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

@Composable
fun SplashScreen() {
    val scale = remember { Animatable(0.4f) }
    val fade = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        launch { scale.animateTo(1f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessLow)) }
        fade.animateTo(1f, tween(700))
    }

    val inf = rememberInfiniteTransition(label = "glow")
    val glow by inf.animateFloat(
        0.5f, 1f,
        infiniteRepeatable(tween(1200, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "g"
    )

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Palette.Bg1, Palette.Bg0))),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.graphicsLayer {
                scaleX = scale.value; scaleY = scale.value; alpha = fade.value
            }
        ) {
            Box(
                Modifier
                    .size(112.dp)
                    .drawBehind {
                        drawCircle(
                            Brush.radialGradient(
                                listOf(Palette.Violet.copy(alpha = 0.6f * glow), Color.Transparent)
                            ),
                            radius = size.minDimension * 0.95f
                        )
                    }
                    .clip(RoundedCornerShape(32.dp))
                    .background(Brush.linearGradient(listOf(Palette.Violet, Palette.Cyan))),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.Bolt, null, tint = Color.White, modifier = Modifier.size(60.dp))
            }
            Spacer(Modifier.height(28.dp))
            Text(
                "EARNING VIRO",
                style = TextStyle(
                    brush = Brush.linearGradient(listOf(Palette.Cyan, Palette.Violet, Palette.Pink)),
                    fontSize = 30.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp
                )
            )
            Spacer(Modifier.height(6.dp))
            Text("PREMIUM SERVERS", color = Palette.TextSecondary, fontSize = 12.sp, letterSpacing = 4.sp)
        }
    }
}
