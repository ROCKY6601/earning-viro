package com.earningviro.app.ads

import android.app.Activity
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.OnUserEarnedRewardListener
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAd
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAdLoadCallback

enum class AdResult { REWARDED, SKIPPED, FAILED }

/**
 * AdMob (Google Mobile Ads) ka poora logic yahin hai — Banner, Rewarded,
 * Interstitial, Rewarded Interstitial aur Native Advanced sab isi se chalte hain.
 */
object AdMobManager {

    // ====== YE VALUES APNE ADMOB DASHBOARD SE MATCH KARO ======
    const val APP_ID = "ca-app-pub-7648842777306286~2192171143"
    const val BANNER_UNIT_ID = "ca-app-pub-7648842777306286/3146160166"
    const val REWARDED_UNIT_ID = "ca-app-pub-7648842777306286/8318595794"
    const val INTERSTITIAL_UNIT_ID = "ca-app-pub-7648842777306286/1267111446"
    const val REWARDED_INTERSTITIAL_UNIT_ID = "ca-app-pub-7648842777306286/5077440507"
    const val NATIVE_UNIT_ID = "ca-app-pub-7648842777306286/6334681851"
    // ============================================================

    private const val TAG = "AdMobManager"
    private val handler = Handler(Looper.getMainLooper())

    var isInitialized by mutableStateOf(false)
        private set
    var isRewardedLoaded by mutableStateOf(false)
        private set
    var isInterstitialLoaded by mutableStateOf(false)
        private set
    var isRewardedInterstitialLoaded by mutableStateOf(false)
        private set

    private var rewardedAd: RewardedAd? = null
    private var interstitialAd: InterstitialAd? = null
    private var rewardedInterstitialAd: RewardedInterstitialAd? = null

    private var isLoadingRewarded = false
    private var isLoadingInterstitial = false
    private var isLoadingRewardedInterstitial = false
    private val rewardedWaiters = mutableListOf<(Boolean) -> Unit>()

    /** App start hote hi ek baar call karo (MainActivity.onCreate) */
    fun initialize(context: Context) {
        if (isInitialized) return
        MobileAds.initialize(context) {
            Log.d(TAG, "AdMob initialized")
            isInitialized = true
            loadRewarded(context)
            loadInterstitial(context)
            loadRewardedInterstitial(context)
        }
    }

    /* ================= REWARDED ================= */

    fun loadRewarded(context: Context, onDone: ((Boolean) -> Unit)? = null) {
        if (rewardedAd != null) { onDone?.invoke(true); return }
        onDone?.let { rewardedWaiters.add(it) }
        if (isLoadingRewarded) return
        isLoadingRewarded = true
        RewardedAd.load(
            context, REWARDED_UNIT_ID, AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    Log.d(TAG, "Rewarded loaded")
                    rewardedAd = ad
                    isRewardedLoaded = true
                    isLoadingRewarded = false
                    flushRewarded(true)
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    Log.e(TAG, "Rewarded load failed: ${error.message}")
                    rewardedAd = null
                    isRewardedLoaded = false
                    isLoadingRewarded = false
                    flushRewarded(false)
                    handler.postDelayed({ loadRewarded(context) }, 30_000)
                }
            }
        )
    }

    private fun flushRewarded(ok: Boolean) {
        val copy = rewardedWaiters.toList()
        rewardedWaiters.clear()
        copy.forEach { it(ok) }
    }

    /**
     * Rewarded ad dikhata hai.
     * REWARDED = user ne pura ad dekha  -> ab server open karo
     * SKIPPED  = beech me band kiya     -> server open MAT karo
     * FAILED   = ad nahi chala          -> message dikhao
     */
    fun showRewarded(activity: Activity, onResult: (AdResult, String?) -> Unit) {
        if (!isInitialized) {
            initialize(activity)
            onResult(AdResult.FAILED, "Ads abhi start ho rahe hain. 5 second baad dobara try karo.")
            return
        }
        val ready = rewardedAd
        if (ready != null) {
            showLoadedRewarded(activity, ready, onResult)
            return
        }

        var finished = false
        val timeout = Runnable {
            if (!finished) {
                finished = true
                onResult(AdResult.FAILED, "Abhi ad available nahi hai. Thodi der baad try karo.")
            }
        }
        handler.postDelayed(timeout, 12_000)
        loadRewarded(activity) { ok ->
            if (finished) return@loadRewarded
            finished = true
            handler.removeCallbacks(timeout)
            val loadedAd = rewardedAd
            if (ok && loadedAd != null) showLoadedRewarded(activity, loadedAd, onResult)
            else onResult(AdResult.FAILED, "Ad load nahi hua. Internet check karke dobara try karo.")
        }
    }

    private fun showLoadedRewarded(activity: Activity, ad: RewardedAd, onResult: (AdResult, String?) -> Unit) {
        rewardedAd = null
        isRewardedLoaded = false
        var earned = false
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                loadRewarded(activity)
                onResult(if (earned) AdResult.REWARDED else AdResult.SKIPPED, null)
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                Log.e(TAG, "Rewarded show failed: ${error.message}")
                loadRewarded(activity)
                onResult(AdResult.FAILED, "Ad chal nahi paya. Dobara try karo.")
            }
        }
        ad.show(activity) { earned = true }
    }

    /* ================= INTERSTITIAL ================= */

    fun loadInterstitial(context: Context) {
        if (interstitialAd != null || isLoadingInterstitial) return
        isLoadingInterstitial = true
        InterstitialAd.load(
            context, INTERSTITIAL_UNIT_ID, AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    Log.d(TAG, "Interstitial loaded")
                    interstitialAd = ad
                    isInterstitialLoaded = true
                    isLoadingInterstitial = false
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    Log.e(TAG, "Interstitial load failed: ${error.message}")
                    interstitialAd = null
                    isInterstitialLoaded = false
                    isLoadingInterstitial = false
                    handler.postDelayed({ loadInterstitial(context) }, 30_000)
                }
            }
        )
    }

    /** Ready ho to interstitial dikhata hai, warna chup-chaap skip. onDone hamesha call hota hai. */
    fun showInterstitial(activity: Activity, onDone: () -> Unit) {
        val ad = interstitialAd
        if (ad == null) { onDone(); return }
        interstitialAd = null
        isInterstitialLoaded = false
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                loadInterstitial(activity)
                onDone()
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                Log.e(TAG, "Interstitial show failed: ${error.message}")
                loadInterstitial(activity)
                onDone()
            }
        }
        ad.show(activity)
    }

    /* ================= REWARDED INTERSTITIAL ================= */

    fun loadRewardedInterstitial(context: Context) {
        if (rewardedInterstitialAd != null || isLoadingRewardedInterstitial) return
        isLoadingRewardedInterstitial = true
        RewardedInterstitialAd.load(
            context, REWARDED_INTERSTITIAL_UNIT_ID, AdRequest.Builder().build(),
            object : RewardedInterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedInterstitialAd) {
                    Log.d(TAG, "Rewarded interstitial loaded")
                    rewardedInterstitialAd = ad
                    isRewardedInterstitialLoaded = true
                    isLoadingRewardedInterstitial = false
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    Log.e(TAG, "Rewarded interstitial load failed: ${error.message}")
                    rewardedInterstitialAd = null
                    isRewardedInterstitialLoaded = false
                    isLoadingRewardedInterstitial = false
                    handler.postDelayed({ loadRewardedInterstitial(context) }, 30_000)
                }
            }
        )
    }

    fun showRewardedInterstitial(activity: Activity, onResult: (AdResult, String?) -> Unit) {
        val ad = rewardedInterstitialAd
        if (ad == null) {
            onResult(AdResult.FAILED, "Bonus ad abhi ready nahi hai. Thodi der baad try karo.")
            loadRewardedInterstitial(activity)
            return
        }
        rewardedInterstitialAd = null
        isRewardedInterstitialLoaded = false
        var earned = false
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                loadRewardedInterstitial(activity)
                onResult(if (earned) AdResult.REWARDED else AdResult.SKIPPED, null)
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                Log.e(TAG, "Rewarded interstitial show failed: ${error.message}")
                loadRewardedInterstitial(activity)
                onResult(AdResult.FAILED, "Bonus ad chal nahi paya. Dobara try karo.")
            }
        }
        ad.show(activity) { earned = true }
    }

    /* ================= BANNER ================= */

    /** Naya Banner AdView banata hai aur load karta hai. Compose me AndroidView ke andar use karo. */
    fun createBannerAdView(context: Context): AdView {
        val adView = AdView(context)
        adView.adUnitId = BANNER_UNIT_ID
        adView.setAdSize(AdSize.BANNER)
        adView.loadAd(AdRequest.Builder().build())
        return adView
    }
}
