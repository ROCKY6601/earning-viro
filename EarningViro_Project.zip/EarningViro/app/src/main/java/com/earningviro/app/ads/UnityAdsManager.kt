package com.earningviro.app.ads

import android.app.Activity
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.unity3d.ads.IUnityAdsInitializationListener
import com.unity3d.ads.IUnityAdsLoadListener
import com.unity3d.ads.IUnityAdsShowListener
import com.unity3d.ads.UnityAds
import com.unity3d.ads.UnityAdsShowOptions
import com.unity3d.services.banners.BannerErrorInfo
import com.unity3d.services.banners.BannerView
import com.unity3d.services.banners.UnityBannerSize

enum class AdResult { REWARDED, SKIPPED, FAILED }

/**
 * Unity Ads (Rewarded) ka poora logic yahin hai.
 * Game ID aur Placement ID Unity Dashboard se liye gaye hain.
 */
object UnityAdsManager {

    // ====== YE 3 VALUES APNE DASHBOARD SE MATCH KARO ======
    const val GAME_ID = "800377542"
    const val REWARDED_PLACEMENT_ID = "BP_Rewarded_Android"

    // Unity Dashboard > Monetization > Placements me "Banner" type ka placement banao
    // aur uska naam yahan daalo (case-sensitive match zaroori hai).
    const val BANNER_PLACEMENT_ID = "BP_Banner_Android"
    const val INTERSTITIAL_PLACEMENT_ID = "BP_Interstitial_Android"

    // FALSE = real ads (live). Testing ke liye TRUE karo.
    const val TEST_MODE = false
    // ======================================================

    private const val TAG = "UnityAdsManager"
    private val handler = Handler(Looper.getMainLooper())

    var isInitialized by mutableStateOf(false)
        private set
    var isAdLoaded by mutableStateOf(false)
        private set

    var isInterstitialLoaded by mutableStateOf(false)
        private set
    private var isInterstitialLoading = false

    private var isInitializing = false
    private var isLoading = false
    private val waiters = mutableListOf<(Boolean) -> Unit>()

    /** App start hote hi ek baar call karo (MainActivity.onCreate) */
    fun initialize(context: Context) {
        if (isInitialized || isInitializing) return
        isInitializing = true
        UnityAds.initialize(
            context.applicationContext,
            GAME_ID,
            TEST_MODE,
            object : IUnityAdsInitializationListener {
                override fun onInitializationComplete() {
                    Log.d(TAG, "Unity Ads initialized")
                    isInitializing = false
                    isInitialized = true
                    loadAd() // turant pehla rewarded ad preload
                    loadInterstitial() // interstitial bhi preload
                }

                override fun onInitializationFailed(
                    error: UnityAds.UnityAdsInitializationError?,
                    message: String?
                ) {
                    Log.e(TAG, "Init failed: $error - $message")
                    isInitializing = false
                }
            }
        )
    }

    /** Ad ko pehle se load karke rakhta hai taaki click par turant chale */
    fun loadAd(onDone: ((Boolean) -> Unit)? = null) {
        if (!isInitialized) { onDone?.invoke(false); return }
        if (isAdLoaded) { onDone?.invoke(true); return }
        onDone?.let { waiters.add(it) }
        if (isLoading) return
        isLoading = true

        UnityAds.load(REWARDED_PLACEMENT_ID, object : IUnityAdsLoadListener {
            override fun onUnityAdsAdLoaded(placementId: String?) {
                Log.d(TAG, "Ad loaded: $placementId")
                isLoading = false
                isAdLoaded = true
                flush(true)
            }

            override fun onUnityAdsFailedToLoad(
                placementId: String?,
                error: UnityAds.UnityAdsLoadError?,
                message: String?
            ) {
                Log.e(TAG, "Ad load failed: $error - $message")
                isLoading = false
                isAdLoaded = false
                flush(false)
                // 30 sec baad khud dobara try
                handler.postDelayed({ loadAd() }, 30_000)
            }
        })
    }

    private fun flush(ok: Boolean) {
        val copy = waiters.toList()
        waiters.clear()
        copy.forEach { it(ok) }
    }

    /**
     * Rewarded ad dikhata hai.
     * REWARDED = user ne pura ad dekha  -> ab server open karo
     * SKIPPED  = beech me band kiya     -> server open MAT karo
     * FAILED   = ad nahi chala          -> message dikhao
     */
    fun showRewarded(activity: Activity, onResult: (AdResult, String?) -> Unit) {
        if (!isInitialized) {
            initialize(activity)
            onResult(AdResult.FAILED, "Ads abhi start ho rahe hain. 5 second baad dobara try karo.")
            return
        }
        if (isAdLoaded) {
            show(activity, onResult)
            return
        }

        // Ad ready nahi hai -> load karke dikhao (max 12 sec wait)
        var finished = false
        val timeout = Runnable {
            if (!finished) {
                finished = true
                onResult(AdResult.FAILED, "Abhi ad available nahi hai. Thodi der baad try karo.")
            }
        }
        handler.postDelayed(timeout, 12_000)
        loadAd { ok ->
            if (finished) return@loadAd
            finished = true
            handler.removeCallbacks(timeout)
            if (ok) show(activity, onResult)
            else onResult(AdResult.FAILED, "Ad load nahi hua. Internet check karke dobara try karo.")
        }
    }




    /* ================= INTERSTITIAL ADS ================= */

    /** Interstitial ko pehle se load karke rakhta hai */
    fun loadInterstitial() {
        if (!isInitialized || isInterstitialLoaded || isInterstitialLoading) return
        isInterstitialLoading = true
        UnityAds.load(INTERSTITIAL_PLACEMENT_ID, object : IUnityAdsLoadListener {
            override fun onUnityAdsAdLoaded(placementId: String?) {
                isInterstitialLoading = false
                isInterstitialLoaded = true
            }

            override fun onUnityAdsFailedToLoad(
                placementId: String?,
                error: UnityAds.UnityAdsLoadError?,
                message: String?
            ) {
                Log.e(TAG, "Interstitial load failed: $error - $message")
                isInterstitialLoading = false
                isInterstitialLoaded = false
                handler.postDelayed({ loadInterstitial() }, 30_000)
            }
        })
    }

    /**
     * Interstitial dikhata hai agar ready ho, warna chup-chaap skip kar deta hai
     * (onDone hamesha call hota hai, chahe ad chala ho ya na chala ho).
     */
    fun showInterstitial(activity: Activity, onDone: () -> Unit) {
        if (!isInitialized || !isInterstitialLoaded) {
            onDone()
            return
        }
        isInterstitialLoaded = false
        UnityAds.show(
            activity,
            INTERSTITIAL_PLACEMENT_ID,
            UnityAdsShowOptions(),
            object : IUnityAdsShowListener {
                override fun onUnityAdsShowFailure(
                    placementId: String?,
                    error: UnityAds.UnityAdsShowError?,
                    message: String?
                ) {
                    loadInterstitial()
                    onDone()
                }

                override fun onUnityAdsShowStart(placementId: String?) {}
                override fun onUnityAdsShowClick(placementId: String?) {}
                override fun onUnityAdsShowComplete(
                    placementId: String?,
                    state: UnityAds.UnityAdsShowCompletionState?
                ) {
                    loadInterstitial()
                    onDone()
                }
            }
        )
    }

    /* ================= BANNER ADS ================= */

    /**
     * Ek naya BannerView banata hai aur load karta hai.
     * Compose me AndroidView ke andar isse use karo.
     */
    fun createBannerView(activity: Activity, listener: BannerLoadListener? = null): BannerView {
        val banner = BannerView(activity, BANNER_PLACEMENT_ID, UnityBannerSize(320, 50))
        banner.listener = object : BannerView.IListener {
            override fun onBannerLoaded(bannerAdView: BannerView?) {
                Log.d(TAG, "Banner loaded")
                listener?.onLoaded()
            }

            override fun onBannerFailedToLoad(bannerAdView: BannerView?, errorInfo: BannerErrorInfo?) {
                Log.e(TAG, "Banner failed: ${errorInfo?.errorCode} ${errorInfo?.errorMessage}")
                listener?.onFailed()
            }

            override fun onBannerClick(bannerAdView: BannerView?) {}
            override fun onBannerLeftApplication(bannerAdView: BannerView?) {}
            override fun onBannerShown(bannerAdView: BannerView?) {}
        }
        banner.load()
        return banner
    }

    interface BannerLoadListener {
        fun onLoaded()
        fun onFailed()
    }

    private fun show(activity: Activity, onResult: (AdResult, String?) -> Unit) {
        isAdLoaded = false // ek ad sirf ek baar dikh sakta hai
        UnityAds.show(
            activity,
            REWARDED_PLACEMENT_ID,
            UnityAdsShowOptions(),
            object : IUnityAdsShowListener {
                override fun onUnityAdsShowFailure(
                    placementId: String?,
                    error: UnityAds.UnityAdsShowError?,
                    message: String?
                ) {
                    Log.e(TAG, "Show failed: $error - $message")
                    loadAd()
                    onResult(AdResult.FAILED, "Ad chal nahi paya. Dobara try karo.")
                }

                override fun onUnityAdsShowStart(placementId: String?) {}
                override fun onUnityAdsShowClick(placementId: String?) {}

                override fun onUnityAdsShowComplete(
                    placementId: String?,
                    state: UnityAds.UnityAdsShowCompletionState?
                ) {
                    loadAd() // agla ad tayyar rakho
                    if (state == UnityAds.UnityAdsShowCompletionState.COMPLETED) {
                        onResult(AdResult.REWARDED, null)
                    } else {
                        onResult(AdResult.SKIPPED, null)
                    }
                }
            }
        )
    }
}
