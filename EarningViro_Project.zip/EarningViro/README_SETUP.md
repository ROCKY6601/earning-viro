# EARNING VIRO – Setup Guide (Step by Step)

## Step 1 – Naya project
Android Studio → New Project → **Empty Activity (Compose)**
- Name: Earning Viro
- Package name: `com.earningviro.app`  (agar alag rakha to har file ki pehli `package` line badal dena)
- Minimum SDK: API 24

## Step 2 – Dependencies (app/build.gradle.kts → dependencies { })
```kotlin
implementation("androidx.compose.material:material-icons-extended")
implementation("com.unity3d.ads:unity-ads:4.16.1")
```
(Compose BOM, material3, activity-compose template me pehle se hote hain.)
`settings.gradle.kts` me `mavenCentral()` hona chahiye (default me hota hai).
Sync Now dabao.

## Step 3 – Files copy karo
Is zip ke andar ki files apne project me isi jagah replace/add karo:
- `AndroidManifest.xml`  (permissions + AD_ID)
- `res/values/themes.xml` (agar tumhare project me already hai to `Theme.EarningViro` ka naam manifest se match karo)
- `MainActivity.kt`
- `ads/UnityAdsManager.kt`
- `data/ServerItem.kt`  ← yahan 3 server ke asli links daalo
- `ui/Theme.kt`, `ui/SplashScreen.kt`, `ui/HomeScreen.kt`

## Step 4 – Unity Dashboard check (screenshot ke hisaab se)
- Game ID: `800377542`  ✔ (UnityAdsManager me daal diya)
- Rewarded Placement ID: `BP_Rewarded_Android` ✔
- Organization core ID / Stats API Key → app me daalne ki zaroorat NAHI.
- Dashboard me placement **Enabled** hona chahiye.

## Step 5 – Test
- `TEST_MODE = true` rakho → test ads aayenge, fill guarantee.
- Run karo → Server card par tap → ad chalega → poora dekhne par link khulega.
- Logcat me tag `UnityAdsManager` search karke errors dekh sakte ho.

## Step 6 – Release se pehle
1. `TEST_MODE = false`
2. Apne hi ads par kabhi click mat karo (account ban ho sakta hai)
3. Release build me R8 on ho to Unity ke proguard rules automatically aate hain.

## Ad flow
Tap → (ad ready?) → Ad chalta hai → COMPLETED → link open
                                   → SKIPPED   → link open NAHI hota
                                   → FAILED    → message dikhta hai
