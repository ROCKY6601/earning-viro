# EARNING VIRO – Setup Guide (AdMob)

## Ads Network
Ab is app me **Unity Ads nahi**, **Google AdMob** use ho raha hai — sab 5 format live hain:
- App ID: ca-app-pub-7648842777306286~2192171143
- Banner: ca-app-pub-7648842777306286/3146160166 (har server ke neeche)
- Rewarded: ca-app-pub-7648842777306286/8318595794 (server tap → ad → link khule)
- Interstitial: ca-app-pub-7648842777306286/1267111446 (app open hote hi splash ke baad)
- Rewarded Interstitial: ca-app-pub-7648842777306286/5077440507 ("Watch & Earn Bonus" button)
- Native Advanced: ca-app-pub-7648842777306286/6334681851 (server list ke neeche card)

## Build steps (GitHub Actions se, PC ke bina)
1. GitHub repo `earning-viro` kholo.
2. `EarningViro_Project.zip` upload karo (wahi naam, purana replace ho jayega).
3. Commit karo — build apne aap chalega.
4. Green tick aane ke baad Releases/Artifacts se naya `app-debug.apk` download karo.
5. Purana app uninstall karke naya install karo.

## Zaroori baatein
- Naya app hone ki wajah se sab AdMob units ka fill (real ad milna) shuru me kam ho sakta hai — kuch ghante se 1-2 din lag sakte hain.
- **Apne khud ke ads par kabhi click mat karo** — AdMob account permanently ban ho sakta hai.
- Native Advanced ad tabhi dikhega jab AdMob se koi ad mile; agar na mile to wo jagah khali rahegi (crash nahi hoga).
