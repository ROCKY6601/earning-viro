# EARNING VIRO – Setup Guide (Unity Ads)

## Ads Network
Is app me **Unity Ads** use ho raha hai — teeno format live hain:
- Game ID: 800381391
- Rewarded: BP_Rewarded_Android (server tap → ad → link khule)
- Interstitial: HUT_JWIWOWO (app open hote hi splash ke baad)
- Banner: BR_ROCKYUUI (har server ke neeche)

## Build steps (GitHub Actions se, PC ke bina)
1. GitHub repo `earning-viro` kholo.
2. `EarningViro_Project.zip` upload karo (wahi naam, purana replace ho jayega).
3. Commit karo — build apne aap chalega.
4. Green tick aane ke baad Releases/Artifacts se naya `app-debug.apk` download karo.
5. Purana app uninstall karke naya install karo.

## Zaroori baatein
- Real ads ka fill shuru me kam ho sakta hai — kuch ghante se 1-2 din lag sakte hain.
- **Apne khud ke ads par kabhi click mat karo** — Unity account ban ho sakta hai.
