# EARNING VIRO – Setup Guide (No Ads)

## Kya badla
- Ab app me **koi ads nahi hai** — Unity Ads poori tarah hata diya gaya hai.
- Server par tap karte hi **seedha link khul jata hai**, koi ad nahi dekhna padta.
- Ab **10 servers** hain (pehle 3 the). Server 1-3 ke asli links pehle se lage hain.
  Server 4 se 10 tak abhi placeholder links (`https://example.com/serverN`) hain —
  jab asli links milenge, `app/src/main/java/com/earningviro/app/data/ServerItem.kt`
  file me har server ke `url = "..."` wali line badal dena.

## Build steps (GitHub Actions se, PC ke bina)
1. GitHub repo `earning-viro` kholo.
2. `EarningViro_Project.zip` upload karo (wahi naam, purana replace ho jayega).
3. Commit karo — build apne aap chalega.
4. Green tick aane ke baad Releases/Artifacts se naya `app-debug.apk` download karo.
5. Purana app uninstall karke naya install karo.
